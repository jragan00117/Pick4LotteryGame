



//Lottery Class----------------------------------------------
function Lottery()
{
    //Variables

     
        
//User numbers
this.userNumbers = [4];
        
//Stores user numbers (local storage bucket)
this.storeUserNum = [4]; 
    
this.checkdups = document.getElementById('button');

this.winNum =  this.userNumbers.concat(this.totalNumbers);
    
this.totalNumbers = [];
    
}


//Functions-------------------------------------------------

//Deducts bet from total and displays an error if purse = $0
Lottery.prototype.totalPurse = function()
    { 
      
    
//           if(this.checkdups==true)
//               {
//                 Lottery.prototype.checkDups();
//                 
//                 console.log(checkdups);
//                                   
//               }
    Lottery.prototype.getUserNums();
    Lottery.prototype.getRnd();
     //console.log(this.purse);
    //return this.purse;
    
           
    }
  
Lottery.prototype.getUserNums = function()
    {
        //Variables to store user numbers
        this.userNumber1 = document.getElementById("userNum1");
        this.userNumber2 = document.getElementById("userNum2");
        this.userNumber3 = document.getElementById("userNum3");
        this.userNumber4 = document.getElementById("userNum4");             
        this.userNumbers = [ this.userNumber1.value, this.userNumber2.value, this.userNumber3.value, this.userNumber4.value];
         for( var i = 0; i<this.userNumbers.length;i++)
             {
                 this.userNumbers[i] = +this.userNumbers[i];
                
                 
             }
    Lottery.prototype.checkValue();
     return this.userNumbers;
    
    }

//Generates random number and removes duplicates-------------
Lottery.prototype.getRnd=function()
{
        this.generatedNumbers = [1, 2, 3, 4, 5,6,7,8,9,10];
        
        this.pool = [];
        
        for( var i = 0; i <= 5; i++)
            {
                this.rand = Math.floor(Math.random()* this.generatedNumbers.length);
                this.result = this.generatedNumbers.splice(this.rand,1);
                this.pool.push(this.result);                
            }

    Lottery.prototype.arraySort();
    document.getElementById("this.generatedNumbers").innerHTML = this.generatedNumbers;
    return this.generatedNumbers;
    }
    
//**********************************************************
    Lottery.prototype.arraySort=function()
    {
        
        this.totalNumbers = new Array();
      
       
        
        //remove duplicates from an array
        for(var i = 0; i < this.generatedNumbers.length; i++)
            {
                if($.inArray(this.generatedNumbers[i], this.userNumbers)  == -1)
                    {
                      this.totalNumbers.push(this.generatedNumbers[i]);  
                    }
            }
        this.winNum =  this.userNumbers.concat(this.totalNumbers);
         this.totalNumbers.sort();
    
         console.log(this.userNumbers);
        console.log(this.generatedNumbers);
        console.log(this.winNum);    
        Lottery.prototype.checkWinningNumbers();
    }
    
    
//*********************************************
       
    Lottery.prototype.checkWinningNumbers = function()
        {
                  //Start Pay
               this.purse = 10;

              //bet variable
              this.bet = 2;
        
            this.purse -= this.bet;
          
            if(this.purse == 0)
                {
                alert("You are out of money!");
                location.reload();
                }
        
            if(this.winNum.length == [7])
                {
                    this.purse += this.bet;
                    document.getElementById("payout").innerHTML = this.purse;
                    return;
                }
            if(this.winNum.length == [6])
                {
                    this.purse+= this.purse+4;
                    document.getElementById("payout").innerHTML = this.purse;
                    return;
                }
            if(this.winNum.length == [5])
                {
                    this.purse += this.purse+16;
                    document.getElementById("payout").innerHTML = this.purse;
                    return;
                }
            if(this.winNum.length == [4])
                {
                    this.purse += this.purse+ 64;
                    document.getElementById("payout").innerHTML = this.purse;
                    return;
                }else{
                    console.log(this.userNumbers[1]); 
                    this.purse -= this.bet;
                    document.getElementById("payout").innerHTML = this.purse;
                    return;
                }
        
        }

     
      //Checks for blank textfields,special symbols,letters
     Lottery.prototype.checkValue =function() 
        { 
         //this.sorNum = this.userNumbers.sort();
         this.uniqueNum =[];
         
         for(var i = 0; i < this.userNumbers.length; i++)
             {
                 
                  if(this.userNumbers[i] <= 0)
                     {
                         alert(" You Must enter a number between 1-10!!")
                          this.purse = 10;
                         return;
                     }
                 if(this.userNumbers[1]==this.userNumbers[2]||this.userNumbers[1]==this.userNumbers[3]||this.userNumbers[1]==this.userNumbers[4])
                     {
                         alert(" You Must enter four unique numbers between 1-10!")
                          this.purse = 10;
                         return;
                     }
                  if(this.userNumbers[2]==this.userNumbers[3])
                      {
                          alert(" You Must enter four unique numbers between 1-10!")
                          this.purse = 10;
                         return;
                      }else{
                        return;
                        }
           
                    
            }
     }
         

