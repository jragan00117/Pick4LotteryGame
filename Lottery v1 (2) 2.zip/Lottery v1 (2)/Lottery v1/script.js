



//Lottery Class----------------------------------------------
function Lottery()
{
    //Variables
         
//Start Pay
this.purse = 12;
        
//bet variable
this.bet = 2;
        
//User numbers
this.userNumbers = [4];
        
//Stores user numbers (local storage bucket)
this.storeUserNum = [4]; 
    
this.checkdups = document.getElementById('button');
    
this.totalNumbers = [];
    
}


//Functions-------------------------------------------------

//Deducts bet from total and displays an error if purse = $0
Lottery.prototype.totalPurse = function()
    { 
      this.purse -= this.bet;
      if(this.purse == 0)
        {
          alert("You are out of money!");
          location.reload();
        }
            console.log(this.purse);
            Lottery.prototype.getUserNums();
    
           if(this.checkdups==true)
               {
                 Lottery.prototype.checkDups();
                 
                 console.log(checkdups);
                                   
               }
    Lottery.prototype.getRnd();

           
    }
  
Lottery.prototype.getUserNums = function()
    {
        //Variables to store user numbers
        this.userNumber1 = document.getElementById("userNum1");
        this.userNumber2 = document.getElementById("userNum2");
        this.userNumber3 = document.getElementById("userNum3");
        this.userNumber4 = document.getElementById("userNum4");             
        this.userNumbers = [ this.userNumber1.value, this.userNumber2.value, this.userNumber3.value, this.userNumber4.value];
         for( var i = 0; i<this.userNumbers.length;i++)
             {
                 this.userNumbers[i] = +this.userNumbers[i];
             }
            console.log(this.userNumbers);
     return this.userNumbers;
    }
//TODO DOESNT WORK YET
//Checks for duplicates in uses choice
Lottery.prototype.checkDups = function()
    {
        for (i = 0; i <= 10; i++) 
        {
        this.currentValue = Number(document.getElementById('userNum' + i).value);
            
        if(unique.indexOf(this.currentValue)!=-1)
        {      
            document.getElementById("show").innerHTML = "You must enter 4 unique numbers!";
            return false;
        }
        unique[i]=currentValue;
        }
    }
/////////////////////////////////////////////////////////////

//Generates random number and removes duplicates-------------
Lottery.prototype.getRnd=function()
{
        this.generatedNumbers = [1, 2, 3, 4, 5,6,7,8,9,10];
        
        this.pool = [];
        
        for( var i = 0; i <= 5; i++)
            {
                this.rand = Math.floor(Math.random()* this.generatedNumbers.length);
                this.result = this.generatedNumbers.splice(this.rand,1);
                this.pool.push(this.result);                
            }
        console.log(this.pool);
        console.log(this.pool.length);
        console.log(this.generatedNumbers);      
        console.log(this.generatedNumbers.length);
    Lottery.prototype.arraySort();
    return this.generatedNumbers;
    }
    
//**********************************************************
    Lottery.prototype.arraySort=function()
    {
        
        this.totalNumbers = new Array();
      
       
        
        //remove duplicates from an array
        for(var i = 0; i < this.generatedNumbers.length; i++)
            {
                if($.inArray(this.generatedNumbers[i], this.userNumbers)  == -1)
                    {
                      this.totalNumbers.push(this.generatedNumbers[i]);  
                    }
            }
        this.winNum =  this.userNumbers.concat(this.totalNumbers);
         this.totalNumbers.sort();
    
         console.log(this.userNumbers);
        console.log(this.generatedNumbers);
        console.log(this.winNum);    
        Lottery.prototype.checkWinningNumbers();
    }
    
    
//*********************************************
//TODO This is giving a NAN error     
    Lottery.prototype.checkWinningNumbers = function()
        {
            if(this.winNum.length == [7])
                {
                    this.purse += this.bet;
                    return;
                }
            if(this.winNum.length == [6])
                {
                    this.purse += this.purse + 4;
                    return;
                }
            if(this.winNum.length == [5])
                {
                    this.purse += this.purse + 16;
                    return;
                }
            if(this.winNum.length == [4])
                {
                    this.purse += this.purse + 64;
                    return;
                }else{
                    
                    this.purse -= this.bet;
                }
        console.log(this.purse);      
        }


     
     
     
      //Checks for blank textfields
//        function checkValue()
//        { 
//            var mystring = document.getElementById('myString').value; 
//            if(!mystring.match(/\S/)) {
//            alert ('Empty value is not allowed');
//            return false;
//            } else {
//            alert("correct input");
//            return true;
//            }
//        }

